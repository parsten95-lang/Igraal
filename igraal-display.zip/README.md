# igraal-display
Fertiges Repo für GitHub Pages.

## Nutzung
1. Neues **öffentlichtes (Public)** Repository erstellen, z. B. `igraal-display`.
2. **Diese drei Dateien** hochladen: `index.html`, `igraal.html`, `README.md`.
3. In den Repo-**Settings → Pages**:
   - **Source**: *Deploy from branch*
   - **Branch**: `main`
   - **Folder**: `/root`
4. Nach dem Deploy:
   - Basis-URL: `https://USERNAME.github.io/igraal-display/` (leitet auf `igraal.html`)
   - Direkter Link: `https://USERNAME.github.io/igraal-display/igraal.html`
